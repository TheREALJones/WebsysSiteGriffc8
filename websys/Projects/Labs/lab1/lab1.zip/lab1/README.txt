README
Lab 1
Connor Griffin

The PDF file, "localhost" and the picture, "Part 1" demonstrate that the server is up and running on my computer. The "phpinfo()" PDF file and "lab1-virtualhost" picture demonstrate what happens when the virtual host for lab 1 is working. The "Directory" picture shows what would happen if I typed "lab1.websys" into chrome and there was no index file. The "Directory-websys" picture shows what would happen if I typed "websys" into chrome. The Text and Conf files are important files and files that I changed.

After dealing a little bit with virtual hosts, I'm not entirely comfortable with them but I'm pretty sure that I will end up using them enough over the next assignments that I will get probably used to them. It seems like they are a very useful tool. I had trouble initially, trying to figure out the syntax of what I was supposed to do but after consulting the notes, the internet and my group I think I got a reasonable handle on how to do it.
